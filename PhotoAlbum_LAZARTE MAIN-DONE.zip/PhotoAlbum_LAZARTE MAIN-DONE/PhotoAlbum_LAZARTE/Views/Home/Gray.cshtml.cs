using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PhotoAlbum_LAZARTE.Views.Home
{
    public class GrayModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
