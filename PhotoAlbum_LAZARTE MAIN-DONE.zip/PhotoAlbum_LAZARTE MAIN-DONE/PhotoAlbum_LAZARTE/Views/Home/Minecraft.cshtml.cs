using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PhotoAlbum_LAZARTE.Views.Home
{
    public class MinecraftModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
