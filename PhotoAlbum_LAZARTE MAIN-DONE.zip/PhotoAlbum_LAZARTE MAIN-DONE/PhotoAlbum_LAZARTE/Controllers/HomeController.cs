using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PhotoAlbum_LAZARTE.Models;

namespace PhotoAlbum_LAZARTE.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Minecraft()
    {
        return View();
    }
    public IActionResult Gray()
    {
        return View();
    }
    public IActionResult Orange()
    {
        return View();
    }
    public IActionResult Red()
    {
        return View();
    }
    public IActionResult Brown()
    {
        return View();
    }
    public IActionResult black()
    {
        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
